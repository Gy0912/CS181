## Overview

This project is an AI-controlled tank game using Q-learning to train a tank to survive and score points by avoiding enemies and their bullets, and by shooting at them.

### Main Program(The model)

The main program initializes the game, handles events, and implements the Q-learning algorithm to train the tank.

- `get_state`: Discretizes the tank's position and distances to the nearest enemy and bullet to get the state.
- `choose_action`: Chooses an action based on the exploration-exploitation trade-off.
- `update_q_table`: Updates Q-values based on the agent's experience.
- `get_reward`: Defines the reward function based on the next state.
- `write_score_to_file`: Writes the score to a text file.
- `initialize_game`: Initializes the game with tanks, walls, and props.
- `train_tank`: Runs the game and trains the tank using Q-learning.

## Running the Game to Train or Test

1. Run the main.py program to start the game and begin training the AI.
2. Run the test.py to see the performance when the AI uses the q-table it gets.

## Q-learning Parameters

`LEARNING_RATE`: The rate at which the algorithm updates the Q-values.

- `DISCOUNT_FACTOR`: The factor by which future rewards are discounted.
- `EXPLORATION_RATE`: The rate at which the algorithm explores new actions.
- `EXPLORATION_DECAY`: The rate at which the exploration rate decays.
- `MIN_EXPLORATION_RATE`: The minimum exploration rate.

## Training

The AI is trained using the Q-learning algorithm. The training process involves:

1. Getting the current state.
2. Choosing an action based on the exploration-exploitation trade-off.
3. Performing the action and getting the next state and reward.
4. Updating the Q-table based on the reward and the maximum future reward.
5. Repeating the process for a set number of episodes.

### Bullet Class

The `Bullet` class handles the properties and behaviors of the bullets in the game.

- `__init__`: Initializes the bullet with images for different directions and default properties like speed, life, and strength.
- `changeImage`: Changes the bullet's image based on its direction.
- `move`: Moves the bullet and checks for collisions with the edges of the game area.

### Enemy Tank Class

The `EnemyTank` class handles the properties and behaviors of enemy tanks.

- `__init__`: Initializes the enemy tank with different types, positions, and speeds.
- `shoot`: Handles the shooting behavior of the enemy tank.
- `move`: Moves the enemy tank and checks for collisions with walls, other tanks, and the edges of the game area.

### My Tank Class

The `MyTank` class handles the properties and behaviors of the player's tank.

- `__init__`: Initializes the player's tank with images for different levels and default properties like speed, direction, and life.
- `shoot`: Handles the shooting behavior of the player's tank.
- `levelUp` and `levelDown`: Adjusts the tank's level and updates its properties accordingly.
- Movement methods (`moveUp`, `moveDown`, `moveLeft`, `moveRight`): Moves the tank and checks for collisions.

### Wall Class

The `Wall` class handles the properties and behaviors of the bricks and iron walls in the game.

- `Brick` and `Iron`: Classes for brick and iron wall objects, respectively.
- `Map`: Initializes the game map with predefined positions for bricks and iron walls.

## State Space and Action Space

- `STATE_SPACE`: A tuple representing the state space, including the directions and distances to the nearest enemy(0 for close, 1 for middle, 2 for far) and bullet(0 for close, 1 for middle, 2 for far, 3 for ).
- `ACTION_SPACE`: A list of possible actions (`UP`, `DOWN`, `LEFT`, `RIGHT`, `SHOOT`).

## Saving and Loading Q-table

- The Q-table is saved to a file named `q_table.npy` after training.
- The Q-table can be loaded from the file to continue training or for validation.

## Custom Events

- `DELAYEVENT`: Custom event for delay in creating enemy tanks.
- `ENEMYBULLETNOTCOOLINGEVENT`: Custom event for enemy bullet cooling.
- `MYBULLETNOTCOOLINGEVENT`: Custom event for my tank bullet cooling.
- `NOTMOVEEVENT`: Custom event for enemy tank stationary behavior.

## Scoring

- The score is calculated based on the number of the enemytanks shot by myTank
- Scores are written to a file for analysis.Notes
- Ensure the images and sounds are correctly placed in the respective directories.
- Adjust the Q-learning parameters in the main.py to change the train model.
- The training process can be parallelized using the multiprocessing module for faster results.
