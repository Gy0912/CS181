import numpy as np
q_table_loaded = np.load("q_table.npy")
print(q_table_loaded)
# 将整个Q-table保存到文本文件
def save_q_table_to_file(q_table, filename="q_table.txt"):
    with open(filename, "w") as file:
        for i in range(4):
            for j in range(3):
                for k in range(4):
                    for l in range(4):
                        q_values = q_table[i, j, k, l]
                        file.write("State ({}, {}, {}, {}): {}\n".format(i, j, k, l, q_values))

save_q_table_to_file(q_table_loaded)